#include <ros/ros.h>
#include <serial_port/serial_data.h>
#include <std_msgs/Float32.h>
#include <string.h>

#define DATA_SIZE 20000
char recv_data[DATA_SIZE];
unsigned int write_p = 0,read_p = 0;
unsigned int frame_id = 0;
unsigned int cdi_num = 0,track_output_num = 0,raw_num = 0;
unsigned int read_p_test;
unsigned char got_head = 0;
unsigned int head_index = 0;
unsigned char write_overwrite=0;
unsigned char read_overwrite=0;

#define GET_NUMBER 1
#define GET_POS  2
unsigned int step;

inline unsigned int get_ready_size(void);
inline unsigned char read_onebyte(void);
inline unsigned char read_onebyte_before(unsigned int offset);

unsigned char read_onebyte(unsigned int offset)//改变p
{
    read_p = read_p + offset;
    if(read_p >=DATA_SIZE)
    {
        read_p = read_p - DATA_SIZE;
        return recv_data[read_p];
    }
    else 
    {
        return recv_data[read_p];
    }
}

unsigned char read_onebyte_before(unsigned int offset)//不改变p
{
    if(read_p-offset < 0)
    {
        return recv_data[read_p-offset+DATA_SIZE];
    }
    else 
    {
        return recv_data[read_p-offset];
    }
}


unsigned int get_ready_size(void)
{
    if(write_overwrite>read_overwrite)
    {
        return write_p+DATA_SIZE-read_p;
    }
    else if(write_overwrite == read_overwrite)
    {
        return write_p - read_p;
    }
    else 
    {
        std::cout << "recv_error" << std::endl;
        return 0;
    }
}
unsigned char temp;
unsigned char get_O = 0;
unsigned int O_index = 0;
void calterah_data_Callback(const serial_port::serial_data::ConstPtr &msg)
{
    std_msgs::Float32 x,y,z;
    x.data = 1;
    y.data = 2;
    z.data = 3;
    recv_data[write_p++] = msg->data;
    if(write_p >= DATA_SIZE)
        {
            write_p = 0;
            write_overwrite ++;
        }
    if(read_p >= DATA_SIZE)
        {
            read_p =0;
            read_overwrite ++ ;
            if(read_overwrite == write_overwrite)
            {
                read_overwrite = 0;
                write_overwrite = 0;
            }
        }

        //std::cout << "wp:" << write_p << "    "<<"rp" << read_p << std::endl;
        //std::cout << recv_data[write_p] ;
        if(get_ready_size()>=25)//找桢头
        {
            
            if(read_onebyte(1) == 'O')
            {
                O_index = read_p;
               // std::cout << "off" << read_onebyte(1) << std::endl;
                for(int i=2;i<10;i++)
                {
                    if(read_onebyte_before(i) == 'F')
                    {
                        frame_id = 0;
                        for(int j=i-2;j>1;j--)
                        {
                            frame_id += (read_onebyte_before(j)-48)*pow(10,j-2);
                        }
                        step = GET_NUMBER;
                        get_O = 1;
                        
                        break;
                    } 
                }
                //std::cout << frame_id<< std::endl;
            }
         }
            if(step == GET_NUMBER)
            {
                if(read_onebyte(1) == '!')
                {
                    if(read_p<O_index)
                    {
                        if(read_p+DATA_SIZE-O_index >=8)//2wei
                        {
                            raw_num = read_onebyte_before(1) -48 + (read_onebyte_before(2)-48)*10;
                            track_output_num = read_onebyte_before(4) -48 + (read_onebyte_before(5)-48)*10;
                            cdi_num = read_onebyte_before(7) -48 + (read_onebyte_before(8)-48)*10;
                            step = GET_POS;
                        }
                        else if(read_p+DATA_SIZE-O_index<8)//1wei
                        {
                            raw_num = read_onebyte_before(1) -48;
                            track_output_num = read_onebyte_before(3)-48;
                            cdi_num = read_onebyte_before(5) -48;
                            step = GET_POS;
                        }
                    }
                    else 
                    {
                        if(read_p-O_index >=8)
                        {
                                raw_num = read_onebyte_before(1) -48 + (read_onebyte_before(2)-48)*10;
                                track_output_num = read_onebyte_before(4) -48 + (read_onebyte_before(5)-48)*10;
                            cdi_num = read_onebyte_before(7) -48 + (read_onebyte_before(8)-48)*10;
                            step = GET_POS;
                        }
                        else if(read_p-O_index)
                        {
                             raw_num = read_onebyte_before(1) -48;
                             track_output_num = read_onebyte_before(3)-48;
                            cdi_num = read_onebyte_before(5) -48;
                            step = GET_POS;
                        }
                    }
                }    
                std::cout << cdi_num << "/" <<  track_output_num << "/" << raw_num << "/"<< std::endl;
            }

            if(step == GET_POS)
            {

            }
            
            

       
    

    //std::cout << msg->data;

    //ROS_INFO("x = %f,y = %f,z = %f",x.data,y.data,z.data);
}

int main(int argc, char ** argv)
{
    ros::init(argc,argv,"calterah_data_analyze");
    ros::NodeHandle n;
    ros::Subscriber sub = n.subscribe("serial_data",100,calterah_data_Callback);
    // while(ros::ok())
    // {
    //     ros::Subscriber sub = n.subscribe("serial_data",100,calterah_data_Callback);
    // }
    ros::spin();//反复调用当前可触发的回调函数，阻塞
    return 0;
}
